<div class="form-group">
    <a href="basicdetails_edit.php">
    <button class="btn btn-raised btn-primary">Edit</button>
</a>

</div>

<div class="form-group">
<label for="input01" class="col-sm-2 control-label">Name</label>
<div class="col-sm-10">
    <input name="student_name" type="text" value="<?php echo $student_name?>" class="form-control" id="input01" disabled>
</div>
</div>
<hr class="line-dashed full-witdh-line"/>
<div class="form-group">
<label for="input02" class="col-sm-2 control-label">Email</label>
<div class="col-sm-10">
    <input name="student_email" type="text" value="<?php echo $student_email?>" class="form-control" id="input02" disabled>
</div>
</div>
<hr class="line-dashed full-witdh-line"/>
<div class="form-group">
<label for="input03" class="col-sm-2 control-label">Phone number</label>
<div class="col-sm-10">
    <input name="student_mobile" type="text" value="<?php echo $student_mobile?>" class="form-control" id="input03" disabled>
</div>
<hr class="line-dashed full-witdh-line"/>
<div class="form-group">
<label for="input04" class="col-sm-2 control-label">Address</label>
<div class="col-sm-10">
    <input name="student_address" type="text" value="<?php echo $student_address?>" class="form-control" id="input04" disabled>
</div>
</div>
<hr class="line-dashed full-witdh-line"/>
<div class="form-group">
<label for="input04" class="col-sm-2 control-label">Bio</label>
<div class="col-sm-10">
    <input name="student_bio" type="text" value="<?php echo $student_bio?>" class="form-control" disabled> 
</div>
</div>
<hr class="line-dashed full-witdh-line"/>
<div class="form-group">
<label for="input04" class="col-sm-2 control-label">Degree</label>
<div class="col-sm-10">
    <input name="student_degree" type="text" value="<?php echo $student_degree?>" class="form-control" disabled>
</div>
</div>
<hr class="line-dashed full-witdh-line"/>
<div class="form-group">
<label for="input04" class="col-sm-2 control-label">Year of Passing</label>
<div class="col-sm-10">
    <input name="student_yearofpassing" type="text" value="<?php echo $student_yearofpassing?>" class="form-control" disabled>
</div>
</div>
<hr class="line-dashed full-witdh-line"/>
<div class="form-group">
<label for="input04" class="col-sm-2 control-label">Percentage</label>
<div class="col-sm-10">
    <input name="student_percentage" type="text" value="<?php echo $student_percentage."%"?>" class="form-control" disabled>
</div>
</div>
<hr class="line-dashed full-witdh-line"/>
<div class="form-group">
<label for="input04" class="col-sm-2 control-label">Skill Set</label>
<div class="col-sm-10">
    <input name="student_skill" type="text" value="<?php echo $student_skill?>" class="form-control" disabled>
</div>
</div>
<hr class="line-dashed full-witdh-line"/>
<div class="form-group">
<label for="input04" class="col-sm-2 control-label">Certifications</label>
<div class="col-sm-10">
    <input name="student_certificate" type="text" value="<?php echo $student_certificate?>" class="form-control" disabled>
</div>
</div>
<hr class="line-dashed full-witdh-line"/>
<div class="form-group">
<label for="input04" class="col-sm-2 control-label">Hobby</label>
<div class="col-sm-10">
    <input name="student_hobby" type="text" value="<?php echo $student_hobby?>" class="form-control" disabled>
</div>
</div>
<hr class="line-dashed full-witdh-line"/>
<div class="form-group">
<label for="input04" class="col-sm-2 control-label">Achievements</label>
<div class="col-sm-10">
    <input name="student_achievements" type="text" value="<?php echo $student_achievements?>" class="form-control" disabled>
</div>
</div>
<hr class="line-dashed full-witdh-line"/>
<div class="form-group">
<label for="input04" class="col-sm-2 control-label">Known Languages</label>
<div class="col-sm-10">
    <input name="student_kl" type="text" value="<?php echo $student_kl?>" class="form-control" disabled>
</div>
</div>
<hr class="line-dashed full-witdh-line"/>
<div class="form-group">
<label for="input04" class="col-sm-2 control-label">Projects</label>
<div class="col-sm-10">
    <input name="student_project" type="text" value="<?php echo $student_project?>" class="form-control" disabled>
</div>
</div>
<hr class="line-dashed full-witdh-line"/>
<div class="form-group">
<label for="input04" class="col-sm-2 control-label">Internship</label>
<div class="col-sm-10">
    <input name="student_internship"type="text" value="<?php echo $student_internship?>" class="form-control" disabled>
</div>
</div>
<hr class="line-dashed full-witdh-line"/>
<div class="form-group">
<label for="input04" class="col-sm-2 control-label">Company Name</label>
<div class="col-sm-10">
    <input name="student_companyname" type="text" value="<?php echo $student_companyname?>" class="form-control" disabled>
</div>
</div>
<hr class="line-dashed full-witdh-line"/>
<div class="form-group">
<label for="input04" class="col-sm-2 control-label">Company Address</label>
<div class="col-sm-10">
    <input name="student_companyaddress" type="text" value="<?php echo $student_companyaddress?>" class="form-control" disabled>
</div>
</div>
