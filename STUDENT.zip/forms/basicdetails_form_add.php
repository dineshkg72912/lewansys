<div class="form-group">
<label for="input01" class="col-sm-2 control-label">Name</label>
<div class="col-sm-10">
    <input name="student_name" type="text"  class="form-control" id="input01">
</div>
</div>
<hr class="line-dashed full-witdh-line"/>
<div class="form-group">
<label for="input02" class="col-sm-2 control-label">Email</label>
<div class="col-sm-10">
    <input name="student_email" type="text"  class="form-control" id="input02" >
</div>
</div>
<hr class="line-dashed full-witdh-line"/>
<div class="form-group">
<label for="input03" class="col-sm-2 control-label">Phone number</label>
<div class="col-sm-10">
    <input name="student_mobile" type="text"  class="form-control" id="input03" >
</div>
<hr class="line-dashed full-witdh-line"/>
<div class="form-group">
<label for="input04" class="col-sm-2 control-label">Address</label>
<div class="col-sm-10">
    <input name="student_address" type="text"  class="form-control" id="input04" >
</div>
</div>
<hr class="line-dashed full-witdh-line"/>
<div class="form-group">
<label for="input04" class="col-sm-2 control-label">Bio</label>
<div class="col-sm-10">
    <input name="student_bio" type="text"  class="form-control"> 
</div>
</div>
<hr class="line-dashed full-witdh-line"/>
<div class="form-group">
<label for="input04" class="col-sm-2 control-label">Degree</label>
<div class="col-sm-10">
    <input name="student_degree" type="text"  class="form-control" >
</div>
</div>
<hr class="line-dashed full-witdh-line"/>
<div class="form-group">
<label for="input04" class="col-sm-2 control-label">Year of Passing</label>
<div class="col-sm-10">
    <input name="student_yearofpassing" type="text"  class="form-control" >
</div>
</div>
<hr class="line-dashed full-witdh-line"/>
<div class="form-group">
<label for="input04" class="col-sm-2 control-label">Percentage</label>
<div class="col-sm-10">
    <input name="student_percentage" type="text"  class="form-control" >
</div>
</div>
<hr class="line-dashed full-witdh-line"/>
<div class="form-group">
<label for="input04" class="col-sm-2 control-label">Skill Set</label>
<div class="col-sm-10">
    <input id="skill" name="student_skill" type="text" class="form-control" >
</div>
</div>
<hr class="line-dashed full-witdh-line"/>
<div class="form-group">
<label for="input04" class="col-sm-2 control-label">Certifications</label>
<div class="col-sm-10">
    <input name="student_certificate" type="text"  class="form-control" >
</div>
</div>
<hr class="line-dashed full-witdh-line"/>
<div class="form-group">
<label for="input04" class="col-sm-2 control-label">Hobby</label>
<div class="col-sm-10">
    <input name="student_hobby" type="text"  class="form-control" >
</div>
</div>
<hr class="line-dashed full-witdh-line"/>
<div class="form-group">
<label for="input04" class="col-sm-2 control-label">Achievements</label>
<div class="col-sm-10">
    <input name="student_achievements" type="text" class="form-control" >
</div>
</div>
<hr class="line-dashed full-witdh-line"/>
<div class="form-group">
<label for="input04" class="col-sm-2 control-label">Known Languages</label>
<div class="col-sm-10">
    <input name="student_kl" type="text"  class="form-control" >
</div>
</div>
<hr class="line-dashed full-witdh-line"/>
<div class="form-group">
<label for="input04" class="col-sm-2 control-label">Projects</label>
<div class="col-sm-10">
    <input name="student_project" type="text"  class="form-control" >
</div>
</div>
<hr class="line-dashed full-witdh-line"/>
<div class="form-group">
<label for="input04" class="col-sm-2 control-label">Internship</label>
<div class="col-sm-10">
    <input name="student_internship"type="text"  class="form-control" >
</div>
</div>
<hr class="line-dashed full-witdh-line"/>
<div class="form-group">
<label for="input04" class="col-sm-2 control-label">Company Name</label>
<div class="col-sm-10">
    <input name="student_companyname" type="text"  class="form-control">
</div>
</div>
<hr class="line-dashed full-witdh-line"/>
<div class="form-group">
<label for="input04" class="col-sm-2 control-label">Company Address</label>
<div class="col-sm-10">
    <input name="student_companyaddress" type="text"  class="form-control" >
</div>
</div>
<hr class="line-dashed full-witdh-line"/>
<div class="form-group">
<div class="col-sm-4 col-sm-offset-2">
    
    <button type="submit" class="btn btn-raised btn-default">Save changes</button>
</div>
</div>